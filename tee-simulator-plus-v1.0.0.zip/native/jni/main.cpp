#include "include/teesimplus.h"
// #include "zygisk.h" // Placeholder for Zygisk API header

#include <cstdio>
#include <cstring>
#include <cstdlib>

#define MODULE_PATH "/data/adb/modules/tee-simulator-plus"
#define CONFIG_PATH MODULE_PATH "/config/config.json"

using namespace teesimplus;

// Forward declarations for hook.cpp functions
namespace teesimplus {
namespace hooks {
    int hookAttestKey(/* params placeholder */);
    int hookGenerateKey(/* params placeholder */);
    void unhookAll();
} // namespace hooks
} // namespace teesimplus

// ============================================================================
// Zygisk API type stubs (in real build, these come from zygisk.h)
// These are minimal declarations to illustrate the module structure.
// ============================================================================
namespace zygisk {

struct Api {
    // In the real Zygisk API, this provides:
    // void setOption(Option opt)
    // int connectCompanion()
    // etc.
    void* impl;
};

enum Option {
    // Request to keep the module loaded in the target process
    DLCLOSE_MODULE_LIBRARY = 0,
    // Force the module's library to be kept (not unloaded)
    FORCE_DENYLIST_UNMOUNT = 1,
};

struct AppSpecializeArgs {
    jint* uid;
    jint* gid;
    jintArray* gids;
    jint* runtime_flags;
    jint* mount_external;
    jstring* se_info;
    jstring* nice_name;       // This is the package name
    jstring* instruction_set;
    jstring* app_data_dir;
};

} // namespace zygisk

// ============================================================================
// Config loading — simple JSON parser (no external library)
// ============================================================================
namespace teesimplus {

/**
 * Helper: find a JSON key in a string and return pointer to the value portion.
 * Returns nullptr if key not found.
 */
static const char* findJsonValue(const char* json, const char* key) {
    char searchKey[256];
    snprintf(searchKey, sizeof(searchKey), "\"%s\"", key);

    const char* pos = strstr(json, searchKey);
    if (!pos) return nullptr;

    // Move past the key and the closing quote
    pos += strlen(searchKey);

    // Skip whitespace and colon
    while (*pos && (*pos == ' ' || *pos == '\t' || *pos == '\n' || *pos == '\r' || *pos == ':')) {
        pos++;
    }
    return pos;
}

/**
 * Extract a boolean value from JSON at the given position.
 */
static bool parseBool(const char* valueStart, bool defaultVal) {
    if (!valueStart) return defaultVal;
    if (strncmp(valueStart, "true", 4) == 0) return true;
    if (strncmp(valueStart, "false", 5) == 0) return false;
    return defaultVal;
}

/**
 * Extract a double value from JSON at the given position.
 */
static double parseDouble(const char* valueStart, double defaultVal) {
    if (!valueStart) return defaultVal;
    char* end = nullptr;
    double val = strtod(valueStart, &end);
    if (end == valueStart) return defaultVal;
    return val;
}

/**
 * Extract a quoted string value from JSON at the given position.
 * Returns empty string if not found or null.
 */
static std::string parseString(const char* valueStart) {
    if (!valueStart) return "";
    if (strncmp(valueStart, "null", 4) == 0) return "";
    if (*valueStart != '"') return "";

    const char* start = valueStart + 1;
    const char* end = strchr(start, '"');
    if (!end) return "";

    return std::string(start, end - start);
}

/**
 * Extract an array of strings from JSON at the given position.
 * Expects format: ["str1", "str2", ...]
 */
static std::vector<std::string> parseStringArray(const char* valueStart) {
    std::vector<std::string> result;
    if (!valueStart) return result;
    if (*valueStart != '[') return result;

    const char* pos = valueStart + 1;
    while (*pos) {
        // Skip whitespace
        while (*pos && (*pos == ' ' || *pos == '\t' || *pos == '\n' || *pos == '\r' || *pos == ',')) {
            pos++;
        }

        if (*pos == ']') break;

        if (*pos == '"') {
            const char* strStart = pos + 1;
            const char* strEnd = strchr(strStart, '"');
            if (!strEnd) break;
            result.emplace_back(strStart, strEnd - strStart);
            pos = strEnd + 1;
        } else {
            // Unexpected character, skip
            pos++;
        }
    }

    return result;
}

/**
 * Load and parse config.json from the given path.
 * Uses simple string-based JSON parsing (no external library required).
 */
Config loadConfig(const char* path) {
    Config config = {};
    config.equalizerEnabled = true;
    config.detectionThreshold = 1.1;
    config.referenceProfile.mean = 0.0;
    config.referenceProfile.stddev = 0.0;
    config.hasProfile = false;

    FILE* file = fopen(path, "r");
    if (!file) {
        LOGW("loadConfig: failed to open %s, using defaults", path);
        return config;
    }

    // Read entire file into buffer
    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    fseek(file, 0, SEEK_SET);

    if (fileSize <= 0 || fileSize > 65536) {
        LOGW("loadConfig: invalid file size %ld", fileSize);
        fclose(file);
        return config;
    }

    std::vector<char> buffer(fileSize + 1, '\0');
    size_t bytesRead = fread(buffer.data(), 1, fileSize, file);
    fclose(file);

    if (bytesRead == 0) {
        LOGW("loadConfig: failed to read file contents");
        return config;
    }
    buffer[bytesRead] = '\0';
    const char* json = buffer.data();

    // Parse equalizerEnabled (mapped from latencyEqualizerEnabled in config)
    const char* eqVal = findJsonValue(json, "latencyEqualizerEnabled");
    config.equalizerEnabled = parseBool(eqVal, true);

    // Parse detectionThreshold
    const char* threshVal = findJsonValue(json, "detectionThreshold");
    config.detectionThreshold = parseDouble(threshVal, 1.1);

    // Parse referenceProfile object
    const char* profileVal = findJsonValue(json, "referenceProfile");
    if (profileVal && strncmp(profileVal, "null", 4) != 0) {
        config.hasProfile = true;
        // Look for mean and stddev within the referenceProfile object
        const char* meanVal = findJsonValue(profileVal, "mean");
        config.referenceProfile.mean = parseDouble(meanVal, 0.0);

        const char* stddevVal = findJsonValue(profileVal, "stddev");
        config.referenceProfile.stddev = parseDouble(stddevVal, 0.0);
    }

    // Parse activeKeyboxId
    const char* keyboxVal = findJsonValue(json, "activeKeyboxId");
    config.activeKeyboxId = parseString(keyboxVal);

    // Parse targetList
    const char* targetVal = findJsonValue(json, "targetList");
    config.targetList = parseStringArray(targetVal);

    LOGI("loadConfig: loaded config from %s", path);
    LOGI("  equalizerEnabled=%d, threshold=%.2f, targets=%zu",
         config.equalizerEnabled, config.detectionThreshold, config.targetList.size());

    return config;
}

/**
 * Check if the given package name is in the config's target list.
 */
bool isTargetProcess(const char* packageName, const Config& config) {
    if (!packageName) return false;

    for (const auto& target : config.targetList) {
        if (target == packageName) {
            return true;
        }
    }
    return false;
}

} // namespace teesimplus

// ============================================================================
// Zygisk Module Implementation
// ============================================================================

class TEESimPlusModule {
public:
    /**
     * Called when the module is loaded into the Zygote process.
     * Store the API reference and load configuration.
     */
    void onLoad(zygisk::Api *api, JNIEnv *env) {
        api_ = api;
        env_ = env;
        config_ = loadConfig(CONFIG_PATH);
        LOGI("TEESimulatorPlus Zygisk module loaded");
    }

    /**
     * Called before an app process is specialized (forked from Zygote).
     * Determine if this is a target process and request appropriate behavior.
     */
    void preAppSpecialize(zygisk::AppSpecializeArgs *args) {
        if (!args || !args->nice_name) {
            LOGW("preAppSpecialize: args or nice_name is null");
            shouldUnload_ = true;
            return;
        }

        // Extract package name from jstring
        const char* packageName = env_->GetStringUTFChars(*args->nice_name, nullptr);
        if (!packageName) {
            LOGW("preAppSpecialize: failed to get package name string");
            shouldUnload_ = true;
            return;
        }

        packageName_ = packageName;
        env_->ReleaseStringUTFChars(*args->nice_name, packageName);

        if (isTargetProcess(packageName_.c_str(), config_)) {
            LOGI("preAppSpecialize: target process detected: %s", packageName_.c_str());
            // Request to keep the module loaded in this process
            // In real Zygisk API: api_->setOption(zygisk::FORCE_DENYLIST_UNMOUNT);
            isTarget_ = true;
        } else {
            LOGD("preAppSpecialize: non-target process: %s, requesting unload", packageName_.c_str());
            // Request module unload for non-target processes to save resources
            // In real Zygisk API: api_->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
            shouldUnload_ = true;
        }
    }

    /**
     * Called after an app process has been specialized.
     * If this is a target process, register the attestation hooks.
     */
    void postAppSpecialize(const zygisk::AppSpecializeArgs *args) {
        if (shouldUnload_) {
            return;
        }

        if (isTarget_) {
            LOGI("postAppSpecialize: registering hooks for %s", packageName_.c_str());
            registerHooks();
        }
    }

private:
    zygisk::Api *api_ = nullptr;
    JNIEnv *env_ = nullptr;
    Config config_;
    std::string packageName_;
    bool isTarget_ = false;
    bool shouldUnload_ = false;

    /**
     * Register attestation interception hooks via hook.cpp functions.
     */
    void registerHooks() {
        LOGI("registerHooks: installing attestKey and generateKey hooks");
        // In a full implementation, this would use PLT hooking or inline hooking
        // to redirect KeyMint/Keymaster calls through our hook functions:
        //   teesimplus::hooks::hookAttestKey
        //   teesimplus::hooks::hookGenerateKey
        //
        // The actual hooking mechanism would depend on the target:
        // - For binder-based KeyMint: intercept binder transactions
        // - For HAL-based Keymaster: hook the HAL service functions
        LOGI("registerHooks: hooks installed successfully for %s", packageName_.c_str());
    }
};

// ============================================================================
// Zygisk Module Registration
// ============================================================================
//
// In a real build with the Zygisk API header (zygisk.h), registration is done
// via the REGISTER_ZYGISK_MODULE macro:
//
//   REGISTER_ZYGISK_MODULE(TEESimPlusModule)
//
// This macro expands to create the required entry point that the Zygisk
// framework calls when loading the module. It essentially generates:
//
//   extern "C" void zygisk_module_entry(zygisk::Api *api, JNIEnv *env) {
//       static TEESimPlusModule module;
//       module.onLoad(api, env);
//   }
//
// Along with companion process entry points and version information.
// The Zygisk framework discovers this symbol when loading the .so library
// and uses it to initialize the module within the Zygote process.
//
// For compilation, include the actual zygisk.h from:
//   https://github.com/topjohnwu/zygisk-module-sample
// ============================================================================

// Simulated registration for development/reference purposes:
// REGISTER_ZYGISK_MODULE(TEESimPlusModule)
